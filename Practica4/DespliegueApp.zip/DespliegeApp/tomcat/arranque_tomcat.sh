#!/bin/bash


cd apache-tomcat-8.5.47/bin
sh ./startup.sh
