#!/bin/bash

PORTAL_PATH=$HOME/sisinf
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"


if [ ! -d $PORTAL_PATH/mysql ]; then
    mkdir $PORTAL_PATH/mysql
    chmod 777 $PORTAL_PATH/mysql
fi
 
docker stop sisinf-mariadb
docker rm sisinf-mariadb

rm -R -f $PORTAL_PATH/mysql/data
# chmod 777 $DIR/mariadb/*

# docker network create app-tier --driver bridge

docker run -d --name sisinf-mariadb \
    -e MARIADB_ROOT_PASSWORD=sisinf \
    -e MARIADB_DATABASE=sisinf  \
    -v $PORTAL_PATH/mysql:/bitnami/mariadb \
    -p 3306:3306 \
    bitnami/mariadb:latest

# sleep 20

# docker exec -it sisinf-mariadb /docker-entrypoint-initdb.d/init.sh
# -v $DIR/mariadb:/docker-entrypoint-initdb.d \
    # --network app-tier \
    

