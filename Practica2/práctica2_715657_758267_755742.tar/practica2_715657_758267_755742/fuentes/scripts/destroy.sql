
-- Para la destruccion de todas las tablas
drop table Comentario;
drop table Usuario;
drop table Vehiculo;
drop table Consulta;