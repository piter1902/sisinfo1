var gmapsPlugin = require('../../../plugins/gmaps-heatmap');

console.log(gmapsPlugin);