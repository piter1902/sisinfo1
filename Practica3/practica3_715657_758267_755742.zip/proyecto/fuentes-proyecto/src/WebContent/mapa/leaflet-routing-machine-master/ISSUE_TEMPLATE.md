Hi there,
before submitting a new issue, please consider the following:

* [ ] This is actually an issue with Leaflet Routing Machine, not a question
* [ ] You have read [the Leaflet Routing Machine documentation](http://www.liedman.net/leaflet-routing-machine/api/) and [tutorials](http://www.liedman.net/leaflet-routing-machine/tutorials/)
* [ ] You have looked through existing issues
